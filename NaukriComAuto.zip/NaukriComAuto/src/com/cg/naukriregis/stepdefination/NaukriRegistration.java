package com.cg.naukriregis.stepdefination;


import static org.junit.Assert.assertFalse;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class NaukriRegistration {

	private WebDriver driver;
	@Given("^User open naukri registration page for freshers on browser$")
	public void user_open_naukri_registration_page_for_freshers_on_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\stsSoft\\chromedriver.exe");
		driver=new ChromeDriver(); 
		System.out.println("hi dude");  
		driver.get("https://my.naukri.com");
		driver.manage().window().maximize();
		WebElement field1 = driver.findElement(By.linkText("Register Now"));
		field1.click();
		WebElement field2 = driver.findElement(By.className("fresherCont"));
		field2.click();
	}

	@When("^user enter personal details$")
	public void user_enter_personal_details() throws Throwable {
		WebElement field3 = driver.findElement(By.id("fname"));
		field3.sendKeys("Abhishakey");
		WebElement field4 = driver.findElement(By.id("email"));
		field4.sendKeys("hilaabhiy174556@gmail.com");
		WebElement field5 = driver.findElement(By.name("password"));
		field5.sendKeys("upanddowny");
		WebElement field6 = driver.findElement(By.name("number"));
		field6.sendKeys("9669966996");
//		WebElement field7 = driver.findElement(By.name("city"));
//		List<WebElement> options = (List<WebElement>) field7.findElement(By.id("cityId"));
//		for(WebElement option:options) {
//			if("Nagpur".equals(option.getText()));
//			option.click();
		//}
		
		WebElement field7=driver.findElement(By.name("city"));
		field7.sendKeys("Dahej");
	
	/*	WebElement field7 = driver.findElements(By.name("city")).get(0);
		field7.click();*/
		
		WebElement field8 = driver.findElement(By.id("term"));
		if(!field8.isSelected()) 
			field8.click();
		else 
			System.out.println("Already selected ");
		
		WebElement btnSumit=driver.findElement(By.name("basicDetailSubmit"));
		
		btnSumit.click();
	
	}
	
	
	
	//email   ........    mobile    city
	
	@Then("^Clicks on Register Now$")
	public void clicks_on_Register_Now() throws Throwable {
		
	
		WebDriverWait wait = new WebDriverWait(driver, 100);
		
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.name("qualification_0")));
//		
//		WebElement box1=driver.findElement(By.name("qualification_0"));
//		box1.sendKeys("");
//		
		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section[1]/edu-qualification/div/div[1]/div/div/div[1]/ul/li/div/label/input")).click();
		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]/ul/li[3]/div/div/span")).click();
		
		
		
		
		
//		WebElement box2=driver.findElement(By.name("course_0"));
//		box2.sendKeys("B.Tech/B.E.");
		
		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-course/div/div[1]/div/div/div[1]/ul/li/div/label/input")).click();
		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-course/div/div[1]/div/div/div[2]/ul/li/div/div/span")).click();

//		WebElement box3=driver.findElement(By.name("spec_0"));
//		box3.sendKeys("Electronics/Telecommunication");
	
		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-spec/div/div[1]/div/div/div[1]/ul/li/div/label/input")).click();
		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-spec/div/div[1]/div/div/div[2]/ul/li/div/div/span")).click();
		
		
//		WebElement box4=driver.findElement(By.name("institute_0"));
//		box4.sendKeys("Yeshwantrao Chavan College of Engineering, Nagpur");
		
		driver.findElement(By.id("institute_0")).sendKeys("Yeshwantrao Chavan College of Engineering, Nagpur");
		
		
		WebElement box5=driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/div/div/div/div/label[1]"));
		box5.click();
		
//		WebElement box6=driver.findElement(By.name("passingYear_0"));
//		box6.sendKeys("2018");
		
		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-passing/div/div[1]/div/div/div[1]/ul/li/div/label/input")).click();
		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-passing/div/div[1]/div/div/div[2]/ul/li/div/div/span")).click();
		
		
		WebElement box7=driver.findElement(By.name("keyskills"));
		box7.sendKeys("JEE");
		
		WebElement eduSubmit=driver.findElement(By.name("submitEducationDetail"));
		eduSubmit.click();
		
	}

	

}
